
package com.day4;

public class Program9 implements Program7{

	@Override
	public float rateofInterest() {
		// TODO Auto-generated method stub
		return 9.15f;
	}

}
