package com.day4;

public class Program13 {  
    public static void main(String[] args) {  
        String s1 = "point";    
        String s2 = "point";    
        String s3 = "point";  
        System.out.println(s1.equals(s2)); // True because content is same    
        if (s1.equals(s3)) {  
            System.out.println("both strings are equal");  
        }else System.out.println("both strings are unequal");     
    }  
}  