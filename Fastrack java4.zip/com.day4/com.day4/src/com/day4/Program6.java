
package com.day4;

public class Program6 {
	
	public static void main(String[] args) {
		Program4 p1 = new Program5();
		p1.test();
	}

}
