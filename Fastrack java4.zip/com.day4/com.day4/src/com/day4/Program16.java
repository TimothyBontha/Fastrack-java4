package com.day4;


class Program16{  
	 public static void main(String args[]){  
	   String s="Sachin"+" Tendulkar";  
	   System.out.println(s);//Sachin Tendulkar  
	 }  
	} 