
package com.day4;

public class Program3 {
	
	public static void main(String[] args) {
		Program1 b1 = new Program2();
		b1.fun();
	}

}
