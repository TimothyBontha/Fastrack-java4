
package com.day4;

public class Program10 {
	
	public static void main(String[] args) {
		Program7 b1 = new Program9();
		Program7 i1 = new Program8();
		
		System.out.println(b1.rateofInterest());
		System.out.println(i1.rateofInterest());
	}

}
