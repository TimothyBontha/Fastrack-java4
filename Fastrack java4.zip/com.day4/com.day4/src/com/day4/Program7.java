
package com.day4;

public interface Program7 {
	
	float rateofInterest();

}
