
package com.day4;

public class Program5 implements Program4{

	@Override
	public void test() {
		// TODO Auto-generated method stub
		
		System.out.println("Interface Method Implementation");
		
	}
	

}
