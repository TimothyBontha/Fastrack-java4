
package com.day8;

public class Program28 {
	
	void validate(int age) {
		if(age<18) {
			throw new ArithmeticException("not valid");
		}
		else
			System.out.println("welcome to vote");
	}
	
	public static void main(String[] args) {
		Program28 t1 = new Program28();
		t1.validate(19);
	}

}
