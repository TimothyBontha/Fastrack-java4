
package com.day4;

public interface Program4 {
	
	public void test();

}

