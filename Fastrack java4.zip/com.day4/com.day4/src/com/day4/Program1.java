
package com.day4;

public abstract class Program1 {
	
	abstract void fun();

}
