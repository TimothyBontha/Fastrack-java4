package com.day4;

public class Program15 {

}
public class MyClass implements Comparable<MyClass> {
    private int value;

    public MyClass(int value) {
        this.value = value;
    }

    @Override
    public int compareTo(MyClass other) {
        // Compare the current object (this) with the specified object (other)
        if (this.value < other.value) {
            return -1;
        } else if (this.value > other.value) {
            return 1;
        } else {
            return 0;
        }
    }

    // Getter and Setter for value
    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    // toString method to display the object
    @Override
    public String toString() {
        return "MyClass{" +
                "value=" + value +
                '}';
    }

    public static void main(String[] args) {
        MyClass obj1 = new MyClass(10);
        MyClass obj2 = new MyClass(20);

        System.out.println(obj1.compareTo(obj2));
        System.out.println(obj2.compareTo(obj1)); 
        System.out.println(obj1.compareTo(obj1)); 
    }
}