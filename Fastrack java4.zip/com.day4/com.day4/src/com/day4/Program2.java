
package com.day4;

public class Program2 extends Program1{

	@Override
	void fun() {
		// TODO Auto-generated method stub
		
		System.out.println("Derived fun() method called");
		
	}

}
